---
navigation:
  parent: /items_blocks_index.md
  title: Presses
  icon: appliedenergistics2:item.ItemMultiMaterial:13
categories:
- misc ingredients blocks
item_ids:
- appliedenergistics2:item.ItemMultiMaterial:13
- appliedenergistics2:item.ItemMultiMaterial:14
- appliedenergistics2:item.ItemMultiMaterial:15
- appliedenergistics2:item.ItemMultiMaterial:19
- appliedenergistics2:item.ItemMultiMaterial:21
---


