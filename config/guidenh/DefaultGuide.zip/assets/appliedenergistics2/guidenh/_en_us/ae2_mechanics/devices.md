---
navigation:
  parent: /ae2_mechanics_index.md
  title: Devices
  icon: appliedenergistics2:tile.BlockInterface
---

# Devices

A "Device" refers to an AE2 network component that performs some function related to the network itself. They almost always require a channel, with some exceptions, such as [Level Emitters](../items_blocks/level_emitter.md) or [Molecular Assemblers](../items_blocks/molecular_assembler.md).

Some examples include:

*   <ItemLink id="appliedenergistics2:tile.BlockInterface" showIcon="left" />
*   <ItemLink id="appliedenergistics2:item.ItemMultiPart:220" showIcon="left" />
*   <ItemLink id="appliedenergistics2:item.ItemMultiPart:240" showIcon="left" />
*   <ItemLink id="appliedenergistics2:tile.BlockDrive" showIcon="left" />
*   <ItemLink id="appliedenergistics2:item.ItemMultiPart:320" showIcon="left" />
