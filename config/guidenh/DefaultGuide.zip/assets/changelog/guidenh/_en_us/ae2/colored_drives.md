---
navigation:
  title: Color Coded ME Drives
  parent: ae2.md
  icon: appliedenergistics2:tile.BlockDrive
categories:
    - Applied Energistics 2
author: Skorched
date: 2026-05-27
---

# Color Coded ME Drives
The visual rendering of ME Drives has changed! Now when applying a color to a drive, the color is applied to the chassis itself instead of the individual drives!

This allows you to maintain a color-coded storage system, whilst still being able to discern types and tiers of the cells inside from outside the GUI!

<FloatingImage src="../assets/ae2/colored_drives.png" align="left" displayWidth="256">
  <ImageAnnotation>
    An example of a color coded set-up using ME Drives
  </ImageAnnotation>
</FloatingImage>
